package com.bodybuilding.qa.jcombinatorial;

import java.util.*;

/** Represents a factory that creates all possible parameter combinations for a jUnit test.
 * Using such a factory ensures that all possible values of each parameter get tested. Note that when a test only takes
 * one or two parameters, this is equivalent to all-values or all-pairs testing, respectively. For tests with more
 * parameters, sometimes this can produce a huge number of test-cases. This approach is not recommended in those cases
 * unless each test case is extremely fast and any test failure would have extremely serious consequences.
 * @author Jeremy Reeder
 * @version 2011-11-15
 * @since 2011-10-28 */
public class AllCombinationsParameterFactory extends ParameterFactory {
	private static List<List<String>> cartesianProductOfIdLists(List<Set<String>> inputListOfIdSets) {
		List<List<String>> possiblyIncompleteResult = null, moreCompleteResult = new ArrayList<List<String>>();
		moreCompleteResult.add(new ArrayList<String>());
		for (Set<String> idSet : inputListOfIdSets) {
			possiblyIncompleteResult = new ArrayList<List<String>>(moreCompleteResult);
			for (List<String> possiblyIncompleteCombination : possiblyIncompleteResult)
				for (String inputId : idSet) {
					moreCompleteResult.remove(possiblyIncompleteCombination);
					final List<String> moreCompleteCombination = new ArrayList<String>(possiblyIncompleteCombination);
					moreCompleteCombination.add(inputId);
					moreCompleteResult.add(moreCompleteCombination);
				}
		}
		return moreCompleteResult;
	}
	protected List<String[]> createListOfParameterIdCombinations() {
		final List<String[]> listOfParameterIdCombinations;
		final List<List<String>> listOfParameterIdLists = cartesianProductOfIdLists(orderedListOfParameterIdSets);
		listOfParameterIdCombinations = new ArrayList<String[]>();
		for (List<String> parameterIdList : listOfParameterIdLists) {
			final String[] parameterIds = parameterIdList.toArray(new String[0]);
			listOfParameterIdCombinations.add(parameterIds);
		}
		return listOfParameterIdCombinations;
	}
}
