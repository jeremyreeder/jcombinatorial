package com.bodybuilding.qa.jcombinatorial;

import java.util.*;

import junit.framework.Assert;

/** Represents a factory that creates parameter combinations for parameterized jUnit tests using an orthogonal array.
 * Using such a factory ensures, in the minimum number of combinations (i.e. test cases), that all possible groupings of
 * a given number of parameter values (2 or more) get tested. This typically finds most of the bugs that could have been
 * found through exhaustive testing, and it often does so much more efficiently (i.e. with far fewer combinations to
 * test). This is useful when a relatively small number of effective test-cases is desired.
 * @author Jeremy Reeder
 * @version 2011-11-22
 * @since 2011-10-25 */
public abstract class OrthogonalParameterFactory extends ParameterFactory {
	private int dimensionCount; protected int getDimensionCount() { return dimensionCount; }
	
	/** Constructs a factory.
	 * @param dimensionCount number of dimensions in the orthogonal array. */
	protected OrthogonalParameterFactory(int dimensionCount) { this.dimensionCount = dimensionCount; }
	protected abstract List<String[]> createListOfParameterIdCombinations();
	protected void assertSufficientParameters() {
		final int parameterCount = orderedListOfParameterIdSets.size();
		Assert.assertTrue(
			String.format("This parameter factory is only for tests that take at least %d parameters.", dimensionCount),
			parameterCount >= dimensionCount
		);
	}
}
