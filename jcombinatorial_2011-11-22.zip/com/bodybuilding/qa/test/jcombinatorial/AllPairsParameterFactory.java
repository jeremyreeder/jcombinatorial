package com.bodybuilding.qa.jcombinatorial;

import com.bodybuilding.qa.jcombinatorial.jwise.algorithm.basic.BasicAlgorithm;
import com.bodybuilding.qa.jcombinatorial.jwise.core.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** Represents a factory that creates parameter combinations for a jUnit test in a pair-wise manner.
 * Using such a factory ensures, in the minimum number of combinations (i.e. test cases), that all possible pairings of
 * parameter values get tested. This is the most efficient form of orthogonal-array testing and is most useful in a
 * regression-test suite.
 * @author Jeremy Reeder
 * @version 2011-11-15
 * @since 2011-10-26 */
public class AllPairsParameterFactory extends OrthogonalParameterFactory {
	public AllPairsParameterFactory() { super(2); }
	protected List<String[]> createListOfParameterIdCombinations() {
		assertSufficientParameters();
		final int parameterCount = orderedListOfParameterIdSets.size();
		final Domain domain = new Domain();
		int dimensionIndex = 0;
		for (int valueIdSetIndex = 0; valueIdSetIndex < parameterCount; valueIdSetIndex++) {
			final Set<String> inputIdSet = orderedListOfParameterIdSets.get(valueIdSetIndex);
			final String dimensionId = Integer.toString(dimensionIndex++);
			final String[] inputIdListAsArray = inputIdSet.toArray(new String[0]);
			final Dimension dimension = new Dimension(dimensionId, inputIdListAsArray);
			domain.add(dimension);
		}
		final Generator generator = new Generator(domain);
		generator.verbose = false;
		generator.generate(new BasicAlgorithm(5), getDimensionCount());
		final CombinationTable combinationTable = generator.result();
		final List<String[]> listOfValueIdArrays = new ArrayList<String[]>();
		for (Combination combination : combinationTable.combinations()) {
			final String[] valueIds = combination.value;
			final Random random = new Random(0);
			for (int i = 0; i < parameterCount; i++) {
				if (valueIds[i] == null) {
					final Set<String> valueIdSet = orderedListOfParameterIdSets.get(i);
					final String[] inputIds = valueIdSet.toArray(new String[0]);
					final int randomValueIndex = random.nextInt(inputIds.length);
					valueIds[i] = inputIds[randomValueIndex];
				}
			}
			listOfValueIdArrays.add(valueIds);
		}
		return listOfValueIdArrays;
	}
}
