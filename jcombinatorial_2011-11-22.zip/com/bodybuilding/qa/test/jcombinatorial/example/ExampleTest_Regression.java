package com.bodybuilding.qa.jcombinatorial.example;

import com.bodybuilding.qa.jcombinatorial.AllPairsParameterFactory;
import com.bodybuilding.qa.jcombinatorial.ParameterFactory;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.User;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Coupon;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Product;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.Payment;

import org.junit.runners.Parameterized;
import java.util.List;

/** Represents a regression-test (all-pairs) version of ExampleTest.
 * Pairs each value of each parameter to each value of all other parameters.
 * Far from exhaustive, but hopefully will find most bugs. */
public class ExampleTest_Regression extends ExampleTest {
	public ExampleTest_Regression(User user, Product product, Coupon coupon, Payment payment) {
		super(user, product, coupon, payment);
	}

	/** Returns a relatively small list of parameter combinations (i.e. test cases).
	 * @return the combination list. */
	@Parameterized.Parameters public static List<Object[]> listOfParameterCombinations() {
		final ParameterFactory parameterFactory = new AllPairsParameterFactory();
		parameterFactory.setValuesToTestForEachParameter(
			valuesToTestForEachParameter() // use the values suggested by the abstract test
		);
		return parameterFactory.createListOfParameterCombinations();
	}
}
