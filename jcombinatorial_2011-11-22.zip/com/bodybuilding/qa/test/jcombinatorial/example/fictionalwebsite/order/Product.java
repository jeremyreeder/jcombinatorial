package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order;

/* Represents a product that can be purchased through the fictional web-site. */
public enum Product {
	TYPICAL, DROP_SHIP, E_BOOK, GIFT_CERTIFICATE;
}
