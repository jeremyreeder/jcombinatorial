package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite;

/* Represents a user of the fictional web-site. */
public enum User {
	REGISTERED_USER, UNREGISTERED_USER;
}
