package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment;

/* A non-functional dummy wire-transfer implementation of Payment. */
public class WireTransferPayment implements Payment { }
