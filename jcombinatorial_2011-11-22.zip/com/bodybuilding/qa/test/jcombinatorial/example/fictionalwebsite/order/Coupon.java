package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order;

/* Represents a coupon that can be applied toward a purchase on the fictional web-site. */
public enum Coupon {
	FIVE_DOLLARS_OFF, TEN_PERCENT_OFF
}
