package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment;

/* Represents a payment that can be applied toward an order on the fictional web-site. */
public interface Payment { }
