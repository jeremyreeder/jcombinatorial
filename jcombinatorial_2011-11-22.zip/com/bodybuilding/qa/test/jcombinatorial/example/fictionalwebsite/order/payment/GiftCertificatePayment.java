package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment;

/* A non-functional dummy gift-certificate implementation of Payment. */
public class GiftCertificatePayment implements Payment { }
