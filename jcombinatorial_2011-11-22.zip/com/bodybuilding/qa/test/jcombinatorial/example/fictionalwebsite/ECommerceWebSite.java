package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite;

import java.util.List;

import junit.framework.Assert;

import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Coupon;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Order;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Product;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.CreditCardPayment;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.PayPalPayment;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.Payment;

/** A non-functional dummy representation of an e-commerce web-site. */
public class ECommerceWebSite {
	public void placeOrder(Order order) {
		final User user = order.getUser();
		final List<Product> productList = order.getProductList();
		final Coupon coupon = order.getCoupon();
		final List<Payment> paymentList = order.getPaymentList();
		
		for (Product product : productList)
			for (Payment payment : paymentList) {
				// simulation of a pair-wise bug, discoverable with an AllPairsParameterFactory
				Assert.assertFalse( "Failed to apply the coupon.", product == Product.DROP_SHIP && coupon == Coupon.TEN_PERCENT_OFF);
				
				// simulation of a PayPal bug, discoverable with an AllValuesParameterFactory
				Assert.assertFalse("Failed to pay for the order.", payment instanceof PayPalPayment);
				
				// simulation of a three-way bug, discoverable with an AllCombinationsParameterFactory
				Assert.assertFalse(
					"Failed to submit the order.",
					product == Product.E_BOOK && coupon == Coupon.TEN_PERCENT_OFF && payment instanceof CreditCardPayment 
				);				
			}
	}
}
