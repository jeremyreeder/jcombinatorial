package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment;

/* A non-functional dummy PayPal implementation of Payment. */
public class PayPalPayment implements Payment { }
