package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order;

import java.util.ArrayList;
import java.util.List;

import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.User;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.Payment;

/** A representation of an order that can be placed through the fictional web-site. */
public class Order {
	private User user = null;
	private List<Product> productList = new ArrayList<Product>();
	private Coupon coupon = null;
	private List<Payment> paymentList = new ArrayList<Payment>();
	
	public void setUser(User user) { this.user = user; }
	public boolean addProduct(Product product) { return productList.add(product); }
	public void setCoupon(Coupon coupon) { this.coupon = coupon; }
	public boolean addPayment(Payment payment) { return paymentList.add(payment); }
	
	public User getUser() { return user; }
	public List<Product> getProductList() { return productList; }
	public Coupon getCoupon() { return coupon; }
	public List<Payment> getPaymentList() { return paymentList; }
}
