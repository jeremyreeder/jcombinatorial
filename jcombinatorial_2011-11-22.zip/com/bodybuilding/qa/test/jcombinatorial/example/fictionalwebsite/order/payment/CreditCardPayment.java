package com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment;

/* A non-functional dummy credit-card implementation of Payment. */
public class CreditCardPayment implements Payment { }
