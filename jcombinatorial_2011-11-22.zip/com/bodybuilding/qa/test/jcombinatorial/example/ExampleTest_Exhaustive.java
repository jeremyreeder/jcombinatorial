package com.bodybuilding.qa.jcombinatorial.example;

import com.bodybuilding.qa.jcombinatorial.AllCombinationsParameterFactory;
import com.bodybuilding.qa.jcombinatorial.ParameterFactory;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.User;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Coupon;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Product;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.Payment;

import org.junit.runners.Parameterized;
import java.util.List;

/** Represents an exhaustive version of ExampleTest.
 * Tests all possible combinations of the parameter values. */
public class ExampleTest_Exhaustive extends ExampleTest {
	public ExampleTest_Exhaustive(User user, Product product, Coupon coupon, Payment payment) {
		super(user, product, coupon, payment);
	}

	/** Returns a huge list of parameter combinations (i.e. test cases).
	 * @return the combination list. */
	@Parameterized.Parameters public static List<Object[]> listOfParameterCombinations() {
		final ParameterFactory parameterFactory = new AllCombinationsParameterFactory();
		parameterFactory.setValuesToTestForEachParameter(
			valuesToTestForEachParameter() // use the values suggested by the abstract test
		);
		return parameterFactory.createListOfParameterCombinations();
	}
}
