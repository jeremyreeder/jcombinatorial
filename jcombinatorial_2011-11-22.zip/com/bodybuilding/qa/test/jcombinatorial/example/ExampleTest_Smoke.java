package com.bodybuilding.qa.jcombinatorial.example;

import com.bodybuilding.qa.jcombinatorial.AllValuesParameterFactory;
import com.bodybuilding.qa.jcombinatorial.ParameterFactory;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.User;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Coupon;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.Product;
import com.bodybuilding.qa.jcombinatorial.example.fictionalwebsite.order.payment.Payment;

import org.junit.runners.Parameterized;
import java.util.List;

/** Represents a smoke-test (all-values) version of ExampleTest.
 * Tests a very limited number of combinations of parameter values, but ensures that all values get tested. */
public class ExampleTest_Smoke extends ExampleTest {
	public ExampleTest_Smoke(User user, Product product, Coupon coupon, Payment payment) {
		super(user, product, coupon, payment);
	}

	/** Returns a tiny list of parameter combinations (i.e. test cases).
	 * @return the combination list. */
	@Parameterized.Parameters public static List<Object[]> listOfParameterCombinations() {
		final ParameterFactory parameterFactory = new AllValuesParameterFactory();
		parameterFactory.setValuesToTestForEachParameter(
			valuesToTestForEachParameter() // use the values suggested by the abstract test
		);
		return parameterFactory.createListOfParameterCombinations();
	}
}
